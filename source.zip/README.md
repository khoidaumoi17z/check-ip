# NetworkHooks.dylib — GitHub Actions build

Project **source-only**, không yêu cầu file IPA, không tự inject. Kết quả được xuất ra **`NetworkHooks.dylib` (iOS ARM64)**.

## Build trên GitHub

1. Tạo GitHub repository, nhánh `main` (hoặc `master`).
2. Upload **toàn bộ nội dung bên trong** thư mục này lên gốc repository; giữ đúng đường dẫn **`.github/workflows/build-dylib.yml`**.
3. Commit lên nhánh `main`/`master` để GitHub Actions tự chạy. Hoặc vào **Actions → Build NetworkHooks.dylib (iOS ARM64) → Run workflow**.
4. Mở workflow run → mục **Artifacts** → tải **`NetworkHooks-iOS-arm64`**.
5. Giải nén artifact ZIP để lấy **`NetworkHooks.dylib`** và mã SHA-256 kiểm tra file.

**Không cần `ipa_url`, IPA hoặc chế độ signing**; workflow này chỉ biên dịch dylib.

## Kết quả và môi trường

- Output: `dist/NetworkHooks.dylib`
- Nền tảng: iOS arm64, deployment target iOS 14.0
- Framework: Foundation
- Phụ thuộc: [facebook/fishhook](https://github.com/facebook/fishhook), được tải trong workflow.
- GitHub runner: `macos-15` với Xcode, iPhoneOS SDK.

## Cấu hình hiện tại của source

`src/NetworkHooks.m` là **bản triển khai một phần**, có 4 symbol hooks: `getaddrinfo`, `send`, `recv`, `recvmsg`. Mặc định source thay hostname chứa `sharkios` bằng `168.198.161.199` và cổng `80` thông qua `getaddrinfo`; các lời gọi `send/recv/recvmsg` vẫn được chuyển tiếp tới API gốc. Chỉnh cấu hình trong `src/HookConfig.h`. Đây **không phải** bản chuyển mã đầy đủ của `CrashSightPlugin` và không bảo đảm hành vi tương đương.

Chỉ có thể xác nhận file build và kiến trúc sau khi GitHub Actions chạy thành công. File dylib chưa có chữ ký phân phối; việc tự inject, ký lại IPA và thử trên iPhone là các bước riêng. iOS có thể hạn chế fishhook tuỳ tiến trình / vị trí symbol.

## Build cục bộ (Mac + Xcode)

```bash
bash scripts/build_dylib.sh
```

Sẽ tạo `dist/NetworkHooks.dylib`.

## Kiểm tra đích IP và port

Workflow kiểm tra rằng `HookConfig.h` chứa IP `168.198.161.199`, port `80`, và `NetworkHooks.m` chuyển yêu cầu phân giải tên chứa `sharkios` đến cặp địa chỉ này.

```sh
python3 tests/endpoint_check.py
```

Nếu muốn kiểm tra **thực sự mở TCP** từ runner GitHub, vào Actions → Run workflow → chọn `probe_target=true`. Hoặc chạy:

```sh
python3 tests/endpoint_check.py --probe --timeout 5
```

Kết quả `PASS: TCP handshake completed` chỉ chứng minh máy đang thử kết nối TCP tới `168.198.161.199:80` tại thời điểm thử. Không chứng minh đây là proxy HTTP, không chứng minh ứng dụng IPA có gọi `connect()`, và không chứng minh hook đã chạy trên iPhone.

**Giới hạn cần phân biệt:** Source hiện tại **không tự gọi `connect()`**. Hàm `getaddrinfo()` chỉ trả kết quả phân giải IP/port; ứng dụng tự quyết định có kết nối hay không. Nếu caller yêu cầu `AF_INET6` thay vì IPv4, phép phân giải đến IPv4 số có thể thất bại. Muốn xác nhận kết nối trong IPA, cần log `connect()`/`connectx()` thực tế sau khi inject và kiểm tra trên thiết bị.
