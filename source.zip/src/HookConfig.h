#pragma once

// Reconnaissance-derived behavior only. The original dylib contains additional
// routines that cannot be reconstructed from these four wrappers alone.
// 1: replace getaddrinfo hostnames containing "sharkios" with the observed IP.
// 0: observe lookups without modifying DNS results.
#define NETWORK_HOOK_ENABLE_SHARKIOS_MAPPING 1
#define NETWORK_HOOK_TARGET_IP "168.198.161.199"
#define NETWORK_HOOK_TARGET_PORT "80"

// Sample output so high-frequency network traffic does not flood Unified Logging.
#define NETWORK_HOOK_LOG_SAMPLE_MASK 0x3ffu
