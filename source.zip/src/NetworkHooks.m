// Objective-C / iOS 14+, arm64
// Source-mode approximation of the four identified CrashSightPlugin rebinding
// targets. Does NOT duplicate the unknown Objective-C classes or realOpen gate.
// Source mode ALWAYS forwards send/recv/recvmsg to preserve socket semantics.
#import <Foundation/Foundation.h>
#import <os/log.h>
#import <stdatomic.h>
#import <errno.h>
#import <netdb.h>
#import <string.h>
#import <sys/socket.h>
#import "fishhook.h"
#import "HookConfig.h"

static int (*original_getaddrinfo)(const char *, const char *, const struct addrinfo *, struct addrinfo **);
static ssize_t (*original_send)(int, const void *, size_t, int);
static ssize_t (*original_recv)(int, void *, size_t, int);
static ssize_t (*original_recvmsg)(int, struct msghdr *, int);
static _Atomic unsigned int io_counter = 0;

static BOOL sampled(void) {
    return (atomic_fetch_add_explicit(&io_counter, 1U, memory_order_relaxed)
            & NETWORK_HOOK_LOG_SAMPLE_MASK) == 0U;
}

static int wrapped_getaddrinfo(const char *hostname, const char *service,
                               const struct addrinfo *hints, struct addrinfo **result) {
    if (original_getaddrinfo == NULL) return EAI_FAIL;
#if NETWORK_HOOK_ENABLE_SHARKIOS_MAPPING
    if (hostname && strstr(hostname, "sharkios") != NULL) {
        os_log(OS_LOG_DEFAULT, "[CrashSightHooks] remap matched hostname to configured IPv4:80");
        // This is a testable approximation, not byte-for-byte equivalent to
        // the original library's hostname:service matching and internal state.
        return original_getaddrinfo(NETWORK_HOOK_TARGET_IP,
                                    NETWORK_HOOK_TARGET_PORT, hints, result);
    }
#endif
    if (hostname) os_log_debug(OS_LOG_DEFAULT, "[CrashSightHooks] lookup %{private}s", hostname);
    return original_getaddrinfo(hostname, service, hints, result);
}

static ssize_t wrapped_send(int fd, const void *data, size_t length, int flags) {
    if (!original_send) { errno = ENOSYS; return -1; }
    ssize_t n = original_send(fd, data, length, flags);
    int error = errno;
    if (sampled()) os_log_debug(OS_LOG_DEFAULT, "[CrashSightHooks] send fd=%d requested=%zu returned=%zd", fd, length, n);
    errno = error;
    return n;
}

static ssize_t wrapped_recv(int fd, void *data, size_t length, int flags) {
    if (!original_recv) { errno = ENOSYS; return -1; }
    ssize_t n = original_recv(fd, data, length, flags);
    int error = errno;
    if (sampled()) os_log_debug(OS_LOG_DEFAULT, "[CrashSightHooks] recv fd=%d requested=%zu returned=%zd", fd, length, n);
    errno = error;
    return n;
}

static ssize_t wrapped_recvmsg(int fd, struct msghdr *message, int flags) {
    if (!original_recvmsg) { errno = ENOSYS; return -1; }
    ssize_t n = original_recvmsg(fd, message, flags);
    int error = errno;
    if (sampled()) os_log_debug(OS_LOG_DEFAULT, "[CrashSightHooks] recvmsg fd=%d returned=%zd", fd, n);
    errno = error;
    return n;
}

__attribute__((constructor)) static void install_hooks(void) {
    struct rebinding items[] = {
        {"getaddrinfo", (void *)wrapped_getaddrinfo, (void **)&original_getaddrinfo},
        {"recvmsg", (void *)wrapped_recvmsg, (void **)&original_recvmsg},
        {"send", (void *)wrapped_send, (void **)&original_send},
        {"recv", (void *)wrapped_recv, (void **)&original_recv}
    };
    int status = rebind_symbols(items, sizeof(items) / sizeof(items[0]));
    os_log(OS_LOG_DEFAULT, "[CrashSightHooks] installed rebinding status=%d", status);
}
