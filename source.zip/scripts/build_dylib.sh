#!/usr/bin/env bash
set -euo pipefail

# Run only on macOS with Xcode and the iPhoneOS SDK.
if [[ "$(uname -s)" != 'Darwin' ]]; then
  echo 'Xcode on macOS is required for iOS dylib compilation.' >&2
  exit 2
fi

mkdir -p build dist

# Fishhook provides rebinding of imported Mach-O symbols.
# Clone only the two source files used for this build.
if [[ ! -f build/fishhook/fishhook.c || ! -f build/fishhook/fishhook.h ]]; then
  rm -rf build/fishhook
  git clone --depth 1 https://github.com/facebook/fishhook.git build/fishhook
fi

xcrun --sdk iphoneos clang \
  -arch arm64 \
  -miphoneos-version-min=14.0 \
  -dynamiclib -fobjc-arc -O2 -Wall -Wextra \
  -Isrc -Ibuild/fishhook \
  -install_name '@rpath/NetworkHooks.dylib' \
  src/NetworkHooks.m build/fishhook/fishhook.c \
  -framework Foundation \
  -o dist/NetworkHooks.dylib

test -s dist/NetworkHooks.dylib
echo 'Built dist/NetworkHooks.dylib'
