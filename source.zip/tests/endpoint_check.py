#!/usr/bin/env python3
"""Validate configured destination; optionally probe a TCP handshake only."""
import argparse
import pathlib
import re
import socket
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
HEADER = ROOT / "src" / "HookConfig.h"
SOURCE = ROOT / "src" / "NetworkHooks.m"
EXPECTED_IP = "168.198.161.199"
EXPECTED_PORT = 80


def validate_config():
    h = HEADER.read_text()
    s = SOURCE.read_text()
    tests = [
        ("Configured IPv4", rf'^#define\s+NETWORK_HOOK_TARGET_IP\s+"{re.escape(EXPECTED_IP)}"\s*$', h),
        ("Configured service", rf'^#define\s+NETWORK_HOOK_TARGET_PORT\s+"{EXPECTED_PORT}"\s*$', h),
        ("Mapping enabled", r'^#define\s+NETWORK_HOOK_ENABLE_SHARKIOS_MAPPING\s+1\s*$', h),
        ("Mapping trigger", r'strstr\s*\(hostname,\s*"sharkios"\s*\)', s),
        ("Resolution calls system API", r'original_getaddrinfo\s*\(\s*NETWORK_HOOK_TARGET_IP\s*,\s*NETWORK_HOOK_TARGET_PORT', s),
    ]
    ok = True
    for name, pattern, content in tests:
        passed = re.search(pattern, content, re.MULTILINE) is not None
        print(f'{"PASS" if passed else "FAIL"}: {name}')
        ok &= passed
    # Crucial: this source resolves addresses, it does not open TCP connections.
    print('INFO: getaddrinfo produces addrinfo only; connect() is performed by the app if at all.')
    return ok


def check_numeric_addrinfo():
    addresses = socket.getaddrinfo(EXPECTED_IP, EXPECTED_PORT, socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, socket.AI_NUMERICHOST | socket.AI_NUMERICSERV)
    good = any(family == socket.AF_INET and sockaddr[:2] == (EXPECTED_IP, EXPECTED_PORT) for family,_,_,_,sockaddr in addresses)
    print(f'{"PASS" if good else "FAIL"}: sockaddr points to {EXPECTED_IP}:{EXPECTED_PORT} (IPv4 TCP)')
    return good


def probe(timeout):
    print(f'TCP probe: {EXPECTED_IP}:{EXPECTED_PORT}, timeout={timeout:.1f}s')
    try:
        with socket.create_connection((EXPECTED_IP, EXPECTED_PORT), timeout=timeout):
            print('PASS: TCP handshake completed from this machine.')
        print('INFO: this does not prove HTTP/proxy protocol or injected iOS behavior.')
        return True
    except OSError as ex:
        print(f'FAIL: TCP handshake not completed: {ex}')
        return False


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--probe', action='store_true', help='Attempt real TCP connect to configured IP:port')
    p.add_argument('--timeout', type=float, default=5.0)
    args = p.parse_args()
    if not (0.2 <= args.timeout <= 30):
        p.error('--timeout must be between 0.2 and 30 seconds')
    ok = validate_config() and check_numeric_addrinfo()
    if args.probe and ok: ok = probe(args.timeout)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
