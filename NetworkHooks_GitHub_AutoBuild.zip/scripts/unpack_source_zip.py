#!/usr/bin/env python3
"""Extract only the required iOS dylib source and build inputs from a ZIP."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, BadZipFile
import shutil
import stat
import sys

REQUIRED = (
    "src/HookConfig.h",
    "src/NetworkHooks.m",
    "scripts/build_dylib.sh",
)
OPTIONAL = ("tests/endpoint_check.py",)
MAX_ENTRIES = 512
MAX_FILE_BYTES = 30 * 1024 * 1024
MAX_TOTAL_BYTES = 70 * 1024 * 1024


def unpack(zip_file: Path, output: Path) -> None:
    if output.exists():
        raise RuntimeError(f"Output directory already exists: {output}")
    if not zip_file.is_file():
        raise FileNotFoundError(f"Missing ZIP: {zip_file}")
    with ZipFile(zip_file) as archive:
        infos = archive.infolist()
        if len(infos) > MAX_ENTRIES:
            raise RuntimeError("ZIP contains too many entries")
        if sum(i.file_size for i in infos) > MAX_TOTAL_BYTES:
            raise RuntimeError("ZIP exceeds size limit")
        contents = {}
        for info in infos:
            p = PurePosixPath(info.filename)
            if (
                info.filename.startswith("/")
                or "\\" in info.filename
                or ".." in p.parts
                or p.is_absolute()
                or (info.external_attr >> 16) & 0o170000 == stat.S_IFLNK
                or info.file_size > MAX_FILE_BYTES
                or bool(info.flag_bits & 1)
            ):
                raise RuntimeError(f"Unsafe ZIP entry: {info.filename}")
            if not info.is_dir():
                if str(p) in contents:
                    raise RuntimeError(f"Duplicate ZIP path: {p}")
                contents[str(p)] = info

        # A normal source ZIP may be flat or enclosed by one parent folder.
        paths = list(contents)
        bases = set()
        for path in paths:
            if path.endswith("src/NetworkHooks.m"):
                base = path[: -len("src/NetworkHooks.m")]
                if all(base + name in contents for name in REQUIRED):
                    bases.add(base)
        if len(bases) != 1:
            raise RuntimeError("Expected exactly one valid project with src/ and scripts/")
        base = next(iter(bases))
        output.mkdir(parents=True, exist_ok=False)
        for name in (*REQUIRED, *OPTIONAL):
            key = base + name
            if key not in contents:
                if name in REQUIRED:
                    raise RuntimeError(f"Missing required source: {name}")
                continue
            target = output / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(contents[key]) as r, target.open("wb") as w:
                shutil.copyfileobj(r, w)
            print(f"Extracted {name} ({contents[key].file_size} bytes)")
    print(f"Ready: {output}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python3 scripts/unpack_source_zip.py source.zip workspace")
    try:
        unpack(Path(sys.argv[1]), Path(sys.argv[2]))
    except (OSError, BadZipFile, RuntimeError, ValueError) as error:
        raise SystemExit(f"Unpack failed: {error}")
