# GitHub Actions: đưa ZIP lên repo là tự build dylib

Gói này **đã chứa `source.zip`** (bộ source NetworkHooks cũ). Lần đầu cần đưa **các file bên trong gói thiết lập** lên repo để GitHub thấy workflow tại `.github/workflows/build-from-zip.yml`. Từ lần thứ hai, chỉ cần thay `source.zip` ở gốc repository.

## Dùng ngay

1. Tạo repo GitHub, nhánh `main` hoặc `master`.
2. Giải nén `GitHub_ZIP_AutoBuild_Ready.zip` **một lần** và upload 4 thành phần vào gốc repo: `.github/`, `scripts/`, `source.zip`, `README.md`. Giữ đường dẫn thư mục con.
3. Commit: `main` / `master` sẽ chạy workflow **Auto build dylib from ZIP**.
4. Mở **Actions → Auto build dylib from ZIP → run vừa chạy → Artifacts → NetworkHooks-iOS-arm64**.
5. Tải artifact và giải nén để nhận `NetworkHooks.dylib` (iOS arm64) cùng `NetworkHooks.dylib.sha256`.

## Build những lần sau chỉ cần một ZIP

- Nén source theo đúng cấu trúc `src/HookConfig.h`, `src/NetworkHooks.m`, `scripts/build_dylib.sh` (tùy chọn `tests/endpoint_check.py`). ZIP có thể chứa một folder bọc ngoài.
- Đặt tên file **`source.zip`**.
- Upload/ghi đè file `source.zip` ở gốc repo, commit vào `main`/`master`.
- Workflow sẽ tự giải nén trong GitHub runner, kiểm tra, build, upload artifact. Không cần giải nén ZIP source trên iPhone.

**Giới hạn GitHub:** Workflow cần nằm ngoài ZIP trong `.github/workflows`, GitHub không tự tìm workflow bên trong file nén. Vì vậy bước thiết lập lần đầu là bắt buộc.

**Không cần IPA:** Workflow chỉ xuất `.dylib` và mã SHA256. Source cũ chỉ ánh xạ hostname chứa `sharkios` qua `getaddrinfo` tới `168.198.161.199:80`, **không tự thực hiện `connect()`**. Build thành công không chứng minh IP:80 chấp nhận kết nối từ iPhone hoặc IPA sau inject chạy đúng. Chưa có GitHub Actions run thực tế để xác nhận khả năng biên dịch trên `macos-15`.
